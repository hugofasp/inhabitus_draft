inHabitus — Media Kit
=====================

Para imprensa, parceiros e media. Logótipos, sistema de marca e ficha resumo.

CONTEÚDO
--------
inhabitus-brand-onepager.pdf   Ficha de marca (A4): missão, visão, proposta de
                               valor, paleta, tipografia e regras do logótipo.
logos/
  inhabitus.svg                Logótipo principal, a cor (vetorial).
  inhabitus-mono-black.svg     Versão monocromática preta (fundos claros).
  inhabitus-mono-white.svg     Versão monocromática branca (fundos escuros).
  inhabitus-{512,1024,2048}.png        PNG transparente, a cor.
  inhabitus-mono-black-*.png           PNG transparente, preto.
  inhabitus-mono-white-*.png           PNG transparente, branco.
  inhabitus-on-cream.png               Pré-visualização sobre fundo creme.
  inhabitus-on-ink.png                 Pré-visualização sobre fundo escuro.
favicons/                      Favicon no formato da etiqueta inHabitus ("inH"),
                               em 6 fundos: azul, lima, pessego, tinta, branco,
                               preto. SVG + PNG (512/32) + .ico + apple-touch.

REGRAS RÁPIDAS
--------------
- Use a versão a cor sobre fundos claros; a branca sobre fundos escuros.
- Mantenha uma margem livre à volta do logótipo igual à altura da etiqueta azul.
- Tamanho mínimo: 18 mm / 64 px de largura.
- Não distorça, não rode, não recolora a etiqueta, não aplique sombras ou contornos.

CORES
-----
Azul (inHabitus)  #B8D4F1     Tinta   #0A0B0D
Lima (IN3Domus)   #DEF5A8     Creme   #FAFAF7
Pêssego (INOrigens) #F4B988   Azul ação  #5B89FF

TIPOGRAFIA
----------
Space Grotesk (display + texto) · JetBrains Mono (etiquetas + dados)

CONTACTOS
---------
Comercial   sales@inhabitus.com
Imprensa    press@inhabitus.com
Telefone    +351 928 411 855
Site        inhabitus.com
Morada      R. da Indústria 150, 4485-946 Vilar do Pinheiro, PT

© 2026 inHabitus®. Todos os direitos reservados.
